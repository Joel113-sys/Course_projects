Please note that only in the Colab environment can our model provide a similar result as we submitted to Kaggle (This could be because of the version difference of python between Colab and our local anaconda, but we didn't get to figure that out...). And the actual output may slightly differ from the RMSE of that on Kaggle since this model has some randomness within its design.

When it is run on our local anaconda or other environments, our model may perform slightly differently.


Thank you for your understanding!
